

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter gh=response.getWriter();
		
		String u=request.getParameter("uname");
		String p=request.getParameter("pass");
			try
		{
				if(u.equals("admin") && p.equals("admin"))
				{			
		RequestDispatcher j=request.getRequestDispatcher("linkpage.jsp");
		j.include(request, response);
		ServletConfig  config=getServletConfig();
		String name=config.getInitParameter("demo");
		gh.println("Message is"+ name);
				}
					else
					{
						gh.println("loginFailed");
						RequestDispatcher j=request.getRequestDispatcher("logpage.jsp");
						j.include(request, response);
					
						
					}	
				
		}
		catch(Exception e)
		{
			
		}
		
		
}
}
